<?php

return [
    /*
     |--------------------------------------------------------------------------
     | Default Namespace
     |--------------------------------------------------------------------------
     |
     | Define what channels do all your notifications support.
     |
     */
    'channels' => [
        'database',
        //        'mail',
    ],
];
