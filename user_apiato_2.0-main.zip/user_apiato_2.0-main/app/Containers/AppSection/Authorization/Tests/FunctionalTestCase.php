<?php

namespace App\Containers\AppSection\Authorization\Tests;

class FunctionalTestCase extends ContainerTestCase
{
}
