<?php

namespace App\Containers\AppSection\Authorization\Tests\Functional;

use App\Containers\AppSection\Authorization\Tests\FunctionalTestCase;

class ApiTestCase extends FunctionalTestCase
{
}
