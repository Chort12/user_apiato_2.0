<?php

namespace App\Containers\AppSection\Authorization\Tests;

use App\Ship\Parents\Tests\TestCase as ParentTestCase;

class ContainerTestCase extends ParentTestCase
{
}
