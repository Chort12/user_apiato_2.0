<?php

namespace App\Containers\AppSection\Authorization\Tests;

class UnitTestCase extends ContainerTestCase
{
}
