<?php

namespace App\Containers\AppSection\User\Tests;

class UnitTestCase extends ContainerTestCase
{
}
