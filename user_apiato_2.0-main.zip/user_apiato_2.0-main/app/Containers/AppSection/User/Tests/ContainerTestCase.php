<?php

namespace App\Containers\AppSection\User\Tests;

use App\Ship\Parents\Tests\TestCase as ParentTestCase;

class ContainerTestCase extends ParentTestCase
{
}
