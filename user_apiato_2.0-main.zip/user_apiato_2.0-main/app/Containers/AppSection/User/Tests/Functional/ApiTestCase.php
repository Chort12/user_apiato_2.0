<?php

namespace App\Containers\AppSection\User\Tests\Functional;

use App\Containers\AppSection\User\Tests\FunctionalTestCase;

class ApiTestCase extends FunctionalTestCase
{
}
